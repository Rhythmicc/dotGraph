# dotGraph

## Setup:
  `pip3 install dotGrpah_Rhy`

## Usage
  - run `dotGrpah`:
  ![dotGraph](./img/1.png)
  
  - grammar
    - All grammar of 'dot' is support!
